package com.yash.enumeration;

public enum Role {
	ROLE_USER,
	ROLE_ADMIN;
}
