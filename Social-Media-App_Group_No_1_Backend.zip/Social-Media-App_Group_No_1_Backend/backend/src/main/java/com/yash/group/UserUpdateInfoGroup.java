package com.yash.group;

public interface UserUpdateInfoGroup {
}
