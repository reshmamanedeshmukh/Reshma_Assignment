package com.yash.service;

import java.util.List;

import com.yash.entity.Country;

public interface CountryService {
    Country getCountryById(Long id);
    Country getCountryByName(String name);
    List<Country> getCountryList();
}
