package com.yash.enumeration;

public enum NotificationType {
    POST_LIKE,
    POST_COMMENT,
    POST_SHARE,
    COMMENT_LIKE;
}
