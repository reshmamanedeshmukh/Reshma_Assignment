package com.yash.group;

public interface UserUpdateEmailGroup {
}
