package com.yash.group;

public interface UserUpdatePasswordGroup {
}
